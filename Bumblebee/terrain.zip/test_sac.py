from stable_baselines3 import SAC
from hexapod_env import *

# Buat environment
env = HexapodEnv(is_train=False)

# Load model yang sudah dilatih
model = SAC.load("log_hexapod/SAC_2/model_sac.zip")

# Coba model untuk mengendalikan robot
obs, _ = env.reset()
for _ in range(100000):
    action, _ = model.predict(obs, deterministic=True)  # SAC works better with deterministic actions during testing
    obs, reward, terminated, truncated, info = env.step(action)
    done = terminated or truncated
    if done:
        obs, _ = env.reset()
        env.save_logs_to_csv("test_log/logs_test_sac.csv")
        break