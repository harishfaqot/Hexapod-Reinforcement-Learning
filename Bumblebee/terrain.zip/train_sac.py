from stable_baselines3 import SAC
from stable_baselines3.common.vec_env import SubprocVecEnv, VecMonitor
from hexapod_env import *
import os

log_dir = "./log_hexapod/"
n_env = 1

def make_env():
    env = HexapodEnv(is_train=True)
    return env

# Learning rate scheduler (optional)
def linear_schedule(initial_value):
    def func(progress_remaining):
        return initial_value * progress_remaining
    return func

if __name__ == '__main__':
    env = SubprocVecEnv([make_env for _ in range(n_env)])
    env = VecMonitor(env, log_dir)  # Monitor the vectorized env directly
    
    model = SAC("MlpPolicy", env,
                batch_size=256,
                buffer_size=1000000,
                learning_rate=linear_schedule(1e-3),  # 🧠 Use linear decay here!
                gamma=0.99,
                verbose=1,
                ent_coef="auto",
                tensorboard_log=log_dir,
                learning_starts=1000,
                train_freq=1)
    
    
    model.learn(total_timesteps=100)
    # Find the most recently created run directory inside log_base
    subfolders = [f for f in os.listdir(log_dir) if os.path.isdir(os.path.join(log_dir, f))]
    subfolders.sort(key=lambda x: os.path.getctime(os.path.join(log_dir, x)), reverse=True)
    latest_run_dir = os.path.join(log_dir, subfolders[0]) if subfolders else log_dir

    # Save the model to the latest TensorBoard folder
    model_path = os.path.join(latest_run_dir, "model_sac.zip")
    model.save(model_path)
    print(f"Model saved to: {model_path}")