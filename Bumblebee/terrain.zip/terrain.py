import pybullet as p
import pybullet_data
import numpy as np
import math

def add_terrain():
    # Heightfield parameters (smaller terrain)
    size = 10  # 64x64 grid
    height_scale = np.random.uniform(0.1, 0.2)  # Controls terrain roughness

    # Generate small random terrain
    terrain_shape = np.random.uniform(low=-1, high=1, size=(size, size))
    terrain_shape = (terrain_shape / np.max(np.abs(terrain_shape))).flatten()

    # Create heightfield
    terrain_id = p.createCollisionShape(
        shapeType=p.GEOM_HEIGHTFIELD,
        meshScale=[0.5, 0.5, height_scale],  # Smaller scale
        heightfieldTextureScaling=(size - 1) / 2,
        heightfieldData=terrain_shape,
        numHeightfieldRows=size,
        numHeightfieldColumns=size
    )

    # Create terrain body
    terrain_body = p.createMultiBody(0, terrain_id)
    p.changeVisualShape(terrain_body, -1, rgbaColor=[0.3, 0.3, 0.7, 1])  # Greenish terrain

    return terrain_body

def add_field():
    terrain_start_pos = [0, 0, (0.5 * math.sin(math.radians(10))) + 0.005]
    terrain_orientation = p.getQuaternionFromEuler([0, math.radians(10), 0])
    terrain_id = p.loadURDF("models/lapangan.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain_id, -1, lateralFriction=5)

    terrain_start_pos = [-0.98, 0, 0.178]
    terrain_orientation = p.getQuaternionFromEuler([0, 0, 0])
    terrain2_id = p.loadURDF("models/lapangan.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain2_id, -1, lateralFriction=5)

    terrain_start_pos = [-1.97, 0, 0.178/2]
    terrain_orientation = p.getQuaternionFromEuler([0, math.radians(-10), 0])
    terrain3_id = p.loadURDF("models/lapangan.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain3_id, -1, lateralFriction=5)

    terrain_start_pos = [-2.96, 0, 0]
    terrain_orientation = p.getQuaternionFromEuler([0, 0, 0])
    terrain4_id = p.loadURDF("models/lapangan.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain2_id, -1, lateralFriction=5)

    terrain_start_pos = [-2.96 - 0.5, 0, 0]
    terrain_orientation = p.getQuaternionFromEuler([0, 0, math.radians(180)])
    terrain5_id = p.loadURDF("models/tangga.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain4_id, -1, lateralFriction=5)

    terrain_start_pos = [-4.85, 0, 0.5]
    terrain_orientation = p.getQuaternionFromEuler([0, 0, 0])
    terrain6_id = p.loadURDF("models/lapangan.urdf", terrain_start_pos, terrain_orientation, useFixedBase=True)
    p.changeDynamics(terrain5_id, -1, lateralFriction=5)

if __name__ == '__main__':
    # Initialize physics engine
    physics_client = p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    p.loadURDF("plane.urdf")

    # Load terrain
    terrain = add_terrain()

    # Run simulation loop
    while True:
        p.stepSimulation()
